# 🗄️ initDatabase – Base de datos inicial

Este archivo documenta cómo crear e inicializar la base de datos de IBAX.

## Ejemplo
```bash
./ibax initDatabase --dsn "host=localhost user=postgres password=1234 dbname=ibax sslmode=disable"
```
Esto crea la base de datos `ibax` con las tablas iniciales.
