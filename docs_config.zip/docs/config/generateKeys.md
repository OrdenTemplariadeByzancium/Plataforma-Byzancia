# 🔑 generateKeys – Generación de llaves

Este archivo explica cómo generar llaves públicas/privadas para un nodo.

## Ejemplo de uso
```bash
./ibax generateKeys
```
Las llaves se guardan en la carpeta `/keys`.
