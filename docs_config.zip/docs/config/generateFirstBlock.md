# ⛓️ generateFirstBlock – Bloque Génesis

Este archivo describe cómo inicializar el primer bloque de la red.

## Ejemplo
```bash
./ibax generateFirstBlock --public-key=public.key
```
Esto crea el bloque génesis con la clave pública proporcionada.
