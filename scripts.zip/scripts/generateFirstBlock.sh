#!/bin/bash
echo "⛓️ Creando bloque génesis..."
./ibax generateFirstBlock --public-key=public.key
echo "✅ Bloque génesis creado"
