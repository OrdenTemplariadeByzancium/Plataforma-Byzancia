#!/bin/bash
echo "🔑 Generando llaves..."
./ibax generateKeys
echo "✅ Llaves creadas en /keys/"
