#!/bin/bash
echo "🗄️ Inicializando base de datos..."
./ibax initDatabase --dsn "host=localhost user=postgres password=1234 dbname=ibax sslmode=disable"
echo "✅ Base de datos inicializada"
