# 🚀 Instalación de go-ibax

## Requisitos
- Go 1.20+
- PostgreSQL 14+
- Node.js 18+
- Git

## Pasos de instalación
```bash
git clone https://github.com/IBAX-io/go-ibax.git
cd go-ibax
make
```

## Ejecución mínima
```bash
./ibax start
```
